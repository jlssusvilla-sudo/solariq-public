import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ── Solar Projects (client-facing) ──
export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email"),
  clientPhone: text("client_phone"),
  address: text("address").notNull(),
  systemKw: real("system_kw").notNull().default(6),
  panelCount: integer("panel_count").notNull().default(15),
  contractValue: real("contract_value").notNull().default(0),
  shareToken: text("share_token").notNull(), // unique token for client link
  startDate: text("start_date"),
  estimatedEndDate: text("estimated_end_date"),
  notes: text("notes"),
  contractorNotes: text("contractor_notes"),
  status: text("status").notNull().default("survey"), // survey|design|permitting|procurement|installation|inspection|commissioned
  overallProgress: integer("overall_progress").notNull().default(0),
  createdAt: text("created_at").notNull().default(""),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// ── Milestones / Progress Steps ──
export const milestones = sqliteTable("milestones", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  projectId: integer("project_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  phase: text("phase").notNull(),
  status: text("status").notNull().default("pending"), // pending|in_progress|completed|blocked
  completedAt: text("completed_at"),
  sortOrder: integer("sort_order").notNull().default(0),
  photo: text("photo"), // URL/base64
  note: text("note"),
});

export const insertMilestoneSchema = createInsertSchema(milestones).omit({ id: true });
export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;
export type Milestone = typeof milestones.$inferSelect;

// ── Client Messages / Updates ──
export const updates = sqliteTable("updates", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  projectId: integer("project_id").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("update"), // update|milestone|alert|photo
  postedBy: text("posted_by").notNull().default("Contractor"),
  createdAt: text("created_at").notNull().default(""),
  isRead: integer("is_read").notNull().default(0),
});

export const insertUpdateSchema = createInsertSchema(updates).omit({ id: true, createdAt: true });
export type InsertUpdate = z.infer<typeof insertUpdateSchema>;
export type Update = typeof updates.$inferSelect;

// ── FAQ ──
export const faqs = sqliteTable("faqs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  category: text("category").notNull().default("general"),
  sortOrder: integer("sort_order").notNull().default(0),
  published: integer("published").notNull().default(1),
});

export const insertFaqSchema = createInsertSchema(faqs).omit({ id: true });
export type InsertFaq = z.infer<typeof insertFaqSchema>;
export type Faq = typeof faqs.$inferSelect;

// ── Testimonials ──
export const testimonials = sqliteTable("testimonials", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  location: text("location"),
  role: text("role").notNull().default("Homeowner"),
  quote: text("quote").notNull(),
  rating: integer("rating").notNull().default(5),
  systemSize: text("system_size"),
  published: integer("published").notNull().default(1),
  avatarInitials: text("avatar_initials"),
  createdAt: text("created_at").notNull().default(""),
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({ id: true, createdAt: true });
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

// ── Pricing Plans ──
export const pricingPlans = sqliteTable("pricing_plans", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  price: real("price").notNull(),
  billingCycle: text("billing_cycle").notNull().default("month"),
  description: text("description"),
  features: text("features").notNull().default("[]"), // JSON array
  highlighted: integer("highlighted").notNull().default(0),
  ctaLabel: text("cta_label").notNull().default("Get Started"),
  sortOrder: integer("sort_order").notNull().default(0),
  published: integer("published").notNull().default(1),
});

export const insertPricingSchema = createInsertSchema(pricingPlans).omit({ id: true });
export type InsertPricing = z.infer<typeof insertPricingSchema>;
export type PricingPlan = typeof pricingPlans.$inferSelect;

// ── Milestone Photos ──
export const milestonePhotos = sqliteTable("milestone_photos", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  milestoneId: integer("milestone_id").notNull(),
  projectId: integer("project_id").notNull(),
  dataUrl: text("data_url").notNull(), // base64 encoded
  caption: text("caption"),
  photoType: text("photo_type").notNull().default("progress"), // before|progress|after
  createdAt: text("created_at").notNull().default(""),
});
export const insertMilestonePhotoSchema = createInsertSchema(milestonePhotos).omit({ id: true, createdAt: true });
export type InsertMilestonePhoto = z.infer<typeof insertMilestonePhotoSchema>;
export type MilestonePhoto = typeof milestonePhotos.$inferSelect;

// ── E-Signatures ──
export const signatures = sqliteTable("signatures", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  projectId: integer("project_id").notNull(),
  signerName: text("signer_name").notNull(),
  signerRole: text("signer_role").notNull().default("Client"), // Client|Contractor
  signatureDataUrl: text("signature_data_url").notNull(),
  signedAt: text("signed_at").notNull().default(""),
  ipAddress: text("ip_address"),
  agreementText: text("agreement_text"),
});
export const insertSignatureSchema = createInsertSchema(signatures).omit({ id: true, signedAt: true });
export type InsertSignature = z.infer<typeof insertSignatureSchema>;
export type Signature = typeof signatures.$inferSelect;

// ── Notification Preferences ──
export const notificationPrefs = sqliteTable("notification_prefs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  projectId: integer("project_id").notNull(),
  email: text("email"),
  phone: text("phone"),
  emailEnabled: integer("email_enabled").notNull().default(1),
  smsEnabled: integer("sms_enabled").notNull().default(0),
  notifyOnMilestone: integer("notify_on_milestone").notNull().default(1),
  notifyOnUpdate: integer("notify_on_update").notNull().default(1),
});
export const insertNotifSchema = createInsertSchema(notificationPrefs).omit({ id: true });
export type InsertNotif = z.infer<typeof insertNotifSchema>;
export type NotificationPref = typeof notificationPrefs.$inferSelect;

// ── Admin Users (simple auth) ──
export const admins = sqliteTable("admins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull(),
  password: text("password").notNull(), // plain text for demo
  name: text("name").notNull(),
});
