import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { projects, milestones, updates, faqs, testimonials, pricingPlans, admins, milestonePhotos, signatures, notificationPrefs } from "@shared/schema";
import type { InsertProject, Project, InsertMilestone, Milestone, InsertUpdate, Update, InsertFaq, Faq, InsertTestimonial, Testimonial, InsertPricing, PricingPlan, InsertMilestonePhoto, MilestonePhoto, InsertSignature, Signature, InsertNotif, NotificationPref } from "@shared/schema";
import { eq } from "drizzle-orm";

const sqlite = new Database("solariq.db");
const db = drizzle(sqlite);

sqlite.exec(`
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT, client_name TEXT NOT NULL, client_email TEXT,
    client_phone TEXT, address TEXT NOT NULL, system_kw REAL NOT NULL DEFAULT 6,
    panel_count INTEGER NOT NULL DEFAULT 15, contract_value REAL NOT NULL DEFAULT 0,
    share_token TEXT NOT NULL, start_date TEXT, estimated_end_date TEXT,
    notes TEXT, contractor_notes TEXT,
    status TEXT NOT NULL DEFAULT 'survey', overall_progress INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS milestones (
    id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
    title TEXT NOT NULL, description TEXT, phase TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', completed_at TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0, photo TEXT, note TEXT
  );
  CREATE TABLE IF NOT EXISTS updates (
    id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
    message TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'update',
    posted_by TEXT NOT NULL DEFAULT 'Contractor',
    created_at TEXT NOT NULL DEFAULT '', is_read INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS faqs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL,
    answer TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
    sort_order INTEGER NOT NULL DEFAULT 0, published INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, location TEXT,
    role TEXT NOT NULL DEFAULT 'Homeowner', quote TEXT NOT NULL,
    rating INTEGER NOT NULL DEFAULT 5, system_size TEXT,
    published INTEGER NOT NULL DEFAULT 1, avatar_initials TEXT,
    created_at TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS pricing_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    price REAL NOT NULL, billing_cycle TEXT NOT NULL DEFAULT 'month',
    description TEXT, features TEXT NOT NULL DEFAULT '[]',
    highlighted INTEGER NOT NULL DEFAULT 0,
    cta_label TEXT NOT NULL DEFAULT 'Get Started',
    sort_order INTEGER NOT NULL DEFAULT 0, published INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS milestone_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    milestone_id INTEGER NOT NULL, project_id INTEGER NOT NULL,
    data_url TEXT NOT NULL, caption TEXT,
    photo_type TEXT NOT NULL DEFAULT 'progress',
    created_at TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS signatures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL, signer_name TEXT NOT NULL,
    signer_role TEXT NOT NULL DEFAULT 'Client',
    signature_data_url TEXT NOT NULL,
    signed_at TEXT NOT NULL DEFAULT '',
    ip_address TEXT, agreement_text TEXT
  );
  CREATE TABLE IF NOT EXISTS notification_prefs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL, email TEXT, phone TEXT,
    email_enabled INTEGER NOT NULL DEFAULT 1,
    sms_enabled INTEGER NOT NULL DEFAULT 0,
    notify_on_milestone INTEGER NOT NULL DEFAULT 1,
    notify_on_update INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL,
    password TEXT NOT NULL, name TEXT NOT NULL
  );
`);

// Seed data
const adminCount = sqlite.prepare("SELECT COUNT(*) as c FROM admins").get() as any;
if (adminCount.c === 0) {
  sqlite.exec(`INSERT INTO admins VALUES (1,'admin','solariq2026','SolarIQ Admin')`);
}

const faqCount = sqlite.prepare("SELECT COUNT(*) as c FROM faqs").get() as any;
if (faqCount.c === 0) {
  const seedFaqs = [
    ["How long does solar installation take?","Most residential installations take 1–3 days for physical install after permits are approved. The full process from survey to commissioning typically takes 4–8 weeks.","installation",1],
    ["What is net metering and how does it work in the Philippines?","Net metering allows you to sell excess solar energy back to your distribution utility (e.g., Meralco, VECO). Your meter runs backward when you produce more than you consume, effectively reducing your bill. Under ERC rules, residential systems up to 100 kW are eligible.","billing",2],
    ["Do I need a permit to install solar panels?","Yes. In the Philippines you need a building permit from your LGU/DPWH and an electrical permit. For grid-tied systems, you also need approval from your distribution utility for interconnection.","permits",3],
    ["What happens during a power outage?","Standard grid-tied systems automatically shut down during a power outage for safety reasons. If you want power during outages, you need a battery storage system or a hybrid inverter with backup capability.","technical",4],
    ["How do I monitor my solar system's performance?","Your inverter comes with monitoring software accessible via a mobile app or web portal. You can track daily, monthly, and annual energy production, as well as system health alerts.","monitoring",5],
    ["What maintenance is required?","Solar panels require minimal maintenance. We recommend cleaning panels every 3–6 months (more often in dusty or coastal areas), and a professional inspection every 2–3 years. Inverters typically have a 5–10 year warranty.","maintenance",6],
    ["How much can I save on my electricity bill?","Savings depend on your system size, energy consumption, and local tariff. A properly sized 6 kWp system in the Philippines can offset 60–80% of a typical household electricity bill, saving ₱3,000–₱6,000 per month.","billing",7],
    ["Is my roof strong enough for solar panels?","Our survey team will assess your roof's structural integrity before any installation. Most concrete and steel roofs are suitable. If reinforcement is needed, we will advise you before proceeding.","structural",8],
  ];
  const stmt = sqlite.prepare("INSERT INTO faqs (question,answer,category,sort_order,published) VALUES (?,?,?,?,1)");
  seedFaqs.forEach(([q,a,c,o]) => stmt.run(q,a,c,o));
}

const testimonialCount = sqlite.prepare("SELECT COUNT(*) as c FROM testimonials").get() as any;
if (testimonialCount.c === 0) {
  const seeds = [
    ["Maria Santos","Quezon City","Homeowner","SolarIQ made the entire process transparent. I could check my installation progress anytime from my phone. The crew was professional and finished 2 days ahead of schedule!",5,"8 kWp","MS"],
    ["Roberto Reyes","Cebu City","Business Owner","We installed a 25 kWp system for our restaurant. The platform tracked every milestone and the contractor sent us photos at each stage. Our electricity bill dropped by 70%.",5,"25 kWp","RR"],
    ["Ana dela Cruz","Davao City","Homeowner","As someone who knew nothing about solar, the FAQ section answered all my questions. The progress tracker gave me peace of mind during the whole installation.",5,"6 kWp","AD"],
    ["Engr. Jose Magno","Manila","Solar Contractor","The admin dashboard saves me hours every week. I manage 12 active projects and all clients can see their progress in real time. No more endless WhatsApp messages asking for updates.",5,"Contractor","JM"],
    ["Grace Villanueva","Laguna","Homeowner","The change order tracking feature kept us informed when there was a design adjustment. No surprises, no hidden costs. Exactly what you want from a contractor.",5,"10 kWp","GV"],
    ["Carlo Mendoza","Iloilo","SME Owner","From site survey to full commissioning, everything was logged. Our 40 kWp commercial system was installed flawlessly. ROI is tracking ahead of projections.",5,"40 kWp","CM"],
  ];
  const stmt = sqlite.prepare("INSERT INTO testimonials (name,location,role,quote,rating,system_size,published,avatar_initials,created_at) VALUES (?,?,?,?,?,?,1,?,?)");
  seeds.forEach(([n,l,r,q,rt,ss,ai]) => stmt.run(n,l,r,q,rt,ss,ai,new Date().toISOString()));
}

const planCount = sqlite.prepare("SELECT COUNT(*) as c FROM pricing_plans").get() as any;
if (planCount.c === 0) {
  const plans = [
    ["Starter",999,"month","Perfect for new solar contractors with a small client base",JSON.stringify(["Up to 5 active projects","Client progress tracker","Basic milestone tracking","Share link for clients","Email support","SolarIQ branding"]),0,"Start Free Trial",1],
    ["Professional",2499,"month","The complete toolkit for growing contractors",JSON.stringify(["Up to 25 active projects","All Starter features","Photo updates per milestone","Change order tracking","Permit & BOM manager","Priority support","Custom branding / white-label","SMS/email client notifications"]),1,"Start Free Trial",2],
    ["Enterprise",4999,"month","For large contractors and EPCs managing complex portfolios",JSON.stringify(["Unlimited projects","All Pro features","3D solar designer + yield simulation","Structural load calculator","Shading analysis tool","Dedicated account manager","API access for integrations","Custom domain","Team access (up to 10 users)","Investor PDF reports"]),0,"Contact Sales",3],
  ];
  const stmt = sqlite.prepare("INSERT INTO pricing_plans (name,price,billing_cycle,description,features,highlighted,cta_label,sort_order,published) VALUES (?,?,?,?,?,?,?,?,1)");
  plans.forEach(([n,p,b,d,f,h,c,o]) => stmt.run(n,p,b,d,f,h,c,o));
}

// Seed a demo project
const projCount = sqlite.prepare("SELECT COUNT(*) as c FROM projects").get() as any;
if (projCount.c === 0) {
  const token = "demo-abc123";
  sqlite.exec(`INSERT INTO projects (client_name,client_email,address,system_kw,panel_count,contract_value,share_token,start_date,estimated_end_date,status,overall_progress,created_at)
    VALUES ('Juan dela Cruz','juan@example.com','123 Sampaguita St, Quezon City',8,20,192000,'${token}','2026-03-01','2026-04-15','installation',65,'${new Date().toISOString()}')`);
  const pid = (sqlite.prepare("SELECT id FROM projects WHERE share_token=?").get(token) as any).id;
  const phases = [
    [pid,"Site Survey Complete","Roof assessment, shading analysis, and structural review completed","survey","completed","2026-03-05",1],
    [pid,"System Design Approved","Final 8 kWp layout with 20 x 400W panels approved by client","design","completed","2026-03-10",2],
    [pid,"Permits Submitted","Building and electrical permits submitted to Quezon City LGU","permitting","completed","2026-03-15",3],
    [pid,"Permits Approved","All permits cleared. Utility interconnection approved by Meralco","permitting","completed","2026-03-22",4],
    [pid,"Materials Delivered","All panels, inverter, racking, and wiring delivered on-site","procurement","completed","2026-03-28",5],
    [pid,"Racking Installation","Roof mounts and racking rails installed","installation","completed","2026-04-02",6],
    [pid,"Panel Installation","Solar panels mounted and wired","installation","in_progress",null,7],
    [pid,"Inverter & Electrical","Inverter installation and electrical connections","installation","pending",null,8],
    [pid,"Final Inspection","Local authority and utility inspection","inspection","pending",null,9],
    [pid,"Commissioning & Handover","System tested, monitoring set up, client training","commissioned","pending",null,10],
  ];
  const mstmt = sqlite.prepare("INSERT INTO milestones (project_id,title,description,phase,status,completed_at,sort_order) VALUES (?,?,?,?,?,?,?)");
  phases.forEach(([pid,t,d,p,s,c,o]) => mstmt.run(pid,t,d,p,s,c,o));
  const ustmt = sqlite.prepare("INSERT INTO updates (project_id,message,type,posted_by,created_at) VALUES (?,?,?,?,?)");
  [
    [pid,"Welcome to your SolarIQ progress tracker! We'll keep you updated every step of the way.","update","SolarIQ Team","2026-03-01T09:00:00Z"],
    [pid,"Site survey completed. Your roof is in excellent condition — no structural issues found!","milestone","Engr. Santos","2026-03-05T14:30:00Z"],
    [pid,"Great news! All permits have been approved by Quezon City LGU and Meralco. We're ready to order materials.","milestone","Engr. Santos","2026-03-22T10:15:00Z"],
    [pid,"All materials are on-site and inventoried. Installation crew arrives tomorrow morning at 7am.","update","Engr. Santos","2026-03-28T16:45:00Z"],
    [pid,"Panel installation is 60% complete. Looking great up there! We'll send photos this afternoon.","update","Engr. Santos","2026-04-03T11:00:00Z"],
  ].forEach(([pid,m,t,b,c]) => ustmt.run(pid,m,t,b,c));
}

export class Storage {
  // Projects
  getAllProjects() { return db.select().from(projects).all(); }
  getProject(id: number) { return db.select().from(projects).where(eq(projects.id, id)).get(); }
  getProjectByToken(token: string) { return db.select().from(projects).where(eq(projects.shareToken, token)).get(); }
  createProject(data: InsertProject): Project { return db.insert(projects).values({ ...data, createdAt: new Date().toISOString() }).returning().get(); }
  updateProject(id: number, data: Partial<Project>) { return db.update(projects).set(data).where(eq(projects.id, id)).returning().get(); }
  deleteProject(id: number) { db.delete(projects).where(eq(projects.id, id)).run(); }

  // Milestones
  getMilestonesByProject(pid: number) { return db.select().from(milestones).where(eq(milestones.projectId, pid)).all(); }
  createMilestone(data: InsertMilestone): Milestone { return db.insert(milestones).values(data).returning().get(); }
  updateMilestone(id: number, data: Partial<Milestone>) { return db.update(milestones).set(data).where(eq(milestones.id, id)).returning().get(); }
  deleteMilestone(id: number) { db.delete(milestones).where(eq(milestones.id, id)).run(); }

  // Updates
  getUpdatesByProject(pid: number) { return db.select().from(updates).where(eq(updates.projectId, pid)).all(); }
  createUpdate(data: InsertUpdate): Update { return db.insert(updates).values({ ...data, createdAt: new Date().toISOString() }).returning().get(); }
  deleteUpdate(id: number) { db.delete(updates).where(eq(updates.id, id)).run(); }

  // FAQs
  getAllFaqs() { return db.select().from(faqs).all(); }
  getPublishedFaqs() { return sqlite.prepare("SELECT * FROM faqs WHERE published=1 ORDER BY sort_order ASC").all() as Faq[]; }
  createFaq(data: InsertFaq): Faq { return db.insert(faqs).values(data).returning().get(); }
  updateFaq(id: number, data: Partial<Faq>) { return db.update(faqs).set(data).where(eq(faqs.id, id)).returning().get(); }
  deleteFaq(id: number) { db.delete(faqs).where(eq(faqs.id, id)).run(); }

  // Testimonials
  getAllTestimonials() { return db.select().from(testimonials).all(); }
  getPublishedTestimonials() { return sqlite.prepare("SELECT * FROM testimonials WHERE published=1").all() as Testimonial[]; }
  createTestimonial(data: InsertTestimonial): Testimonial { return db.insert(testimonials).values({ ...data, createdAt: new Date().toISOString() }).returning().get(); }
  updateTestimonial(id: number, data: Partial<Testimonial>) { return db.update(testimonials).set(data).where(eq(testimonials.id, id)).returning().get(); }
  deleteTestimonial(id: number) { db.delete(testimonials).where(eq(testimonials.id, id)).run(); }

  // Pricing
  getAllPlans() { return db.select().from(pricingPlans).all(); }
  getPublishedPlans() { return sqlite.prepare("SELECT * FROM pricing_plans WHERE published=1 ORDER BY sort_order ASC").all() as PricingPlan[]; }
  createPlan(data: InsertPricing): PricingPlan { return db.insert(pricingPlans).values(data).returning().get(); }
  updatePlan(id: number, data: Partial<PricingPlan>) { return db.update(pricingPlans).set(data).where(eq(pricingPlans.id, id)).returning().get(); }
  deletePlan(id: number) { db.delete(pricingPlans).where(eq(pricingPlans.id, id)).run(); }

  // Photos
  getPhotosByProject(pid: number) { return db.select().from(milestonePhotos).where(eq(milestonePhotos.projectId, pid)).all(); }
  getPhotosByMilestone(mid: number) { return db.select().from(milestonePhotos).where(eq(milestonePhotos.milestoneId, mid)).all(); }
  createPhoto(data: InsertMilestonePhoto): MilestonePhoto { return db.insert(milestonePhotos).values({ ...data, createdAt: new Date().toISOString() }).returning().get(); }
  deletePhoto(id: number) { db.delete(milestonePhotos).where(eq(milestonePhotos.id, id)).run(); }

  // Signatures
  getSignaturesByProject(pid: number) { return db.select().from(signatures).where(eq(signatures.projectId, pid)).all(); }
  createSignature(data: InsertSignature): Signature { return db.insert(signatures).values({ ...data, signedAt: new Date().toISOString() }).returning().get(); }

  // Notification Prefs
  getNotifPref(pid: number) { return db.select().from(notificationPrefs).where(eq(notificationPrefs.projectId, pid)).get(); }
  upsertNotifPref(pid: number, data: Partial<InsertNotif>): NotificationPref {
    const existing = this.getNotifPref(pid);
    if (existing) return db.update(notificationPrefs).set(data).where(eq(notificationPrefs.id, existing.id)).returning().get()!;
    return db.insert(notificationPrefs).values({ projectId: pid, ...data } as InsertNotif).returning().get();
  }

  // Admin
  getAdmin(username: string, password: string) { return sqlite.prepare("SELECT * FROM admins WHERE username=? AND password=?").get(username, password) as any; }
}

export const storage = new Storage();
