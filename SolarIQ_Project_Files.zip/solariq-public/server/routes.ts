import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import nodemailer from "nodemailer";
import QRCode from "qrcode";

function genToken() {
  return Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10);
}

// Email transporter — uses ethereal (test) if no SMTP env vars set
async function getTransporter() {
  if (process.env.SMTP_HOST) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
  }
  // Create ethereal test account for demo
  const testAccount = await nodemailer.createTestAccount();
  return nodemailer.createTransport({
    host: "smtp.ethereal.email",
    port: 587,
    auth: { user: testAccount.user, pass: testAccount.pass },
  });
}

async function sendNotificationEmail(to: string, clientName: string, projectName: string, message: string, trackingUrl: string) {
  try {
    const transporter = await getTransporter();
    const info = await transporter.sendMail({
      from: '"SolarIQ" <noreply@solariq.app>',
      to,
      subject: `Solar Installation Update — ${projectName}`,
      html: `
        <div style="font-family:Inter,sans-serif;max-width:600px;margin:0 auto;background:#0f1117;color:#e5e7eb;padding:32px;border-radius:12px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <div style="width:36px;height:36px;background:#fbbf24;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px">☀️</div>
            <span style="font-weight:700;font-size:18px;color:#fff">Solar<span style="color:#fbbf24">IQ</span></span>
          </div>
          <h2 style="color:#fff;margin:0 0 8px">Hi ${clientName},</h2>
          <p style="color:#9ca3af;margin:0 0 20px">Your solar installation has a new update:</p>
          <div style="background:#1f2937;border:1px solid #374151;border-radius:8px;padding:16px;margin-bottom:24px">
            <p style="color:#e5e7eb;margin:0;line-height:1.6">${message}</p>
          </div>
          <a href="${trackingUrl}" style="background:#fbbf24;color:#0f1117;font-weight:700;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block">
            View Full Progress →
          </a>
          <p style="color:#6b7280;font-size:12px;margin-top:24px">
            You're receiving this because you have a solar installation project tracked by SolarIQ.<br/>
            <a href="${trackingUrl}" style="color:#fbbf24">${trackingUrl}</a>
          </p>
        </div>
      `,
    });
    console.log("Email sent:", nodemailer.getTestMessageUrl(info));
    return { ok: true, previewUrl: nodemailer.getTestMessageUrl(info) };
  } catch (e: any) {
    console.error("Email error:", e.message);
    return { ok: false, error: e.message };
  }
}

export async function registerRoutes(httpServer: Server, app: Express) {
  // ── Public: Landing data ──
  app.get("/api/public/faqs", (_req, res) => res.json(storage.getPublishedFaqs()));
  app.get("/api/public/testimonials", (_req, res) => res.json(storage.getPublishedTestimonials()));
  app.get("/api/public/pricing", (_req, res) => res.json(storage.getPublishedPlans()));

  // ── Public: Client progress tracker ──
  app.get("/api/track/:token", (req, res) => {
    const project = storage.getProjectByToken(req.params.token);
    if (!project) return res.status(404).json({ error: "Project not found. Check your link." });
    const ms = storage.getMilestonesByProject(project.id);
    const upd = storage.getUpdatesByProject(project.id);
    const photos = storage.getPhotosByProject(project.id);
    const sigs = storage.getSignaturesByProject(project.id);
    res.json({
      project,
      milestones: ms.sort((a, b) => a.sortOrder - b.sortOrder),
      updates: upd.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
      photos,
      signatures: sigs,
    });
  });

  // ── Public: QR Code ──
  app.get("/api/qr/:token", async (req, res) => {
    const project = storage.getProjectByToken(req.params.token);
    if (!project) return res.status(404).json({ error: "Not found" });
    const host = `${req.protocol}://${req.get("host")}`;
    const trackUrl = `${host}/#/track/${req.params.token}`;
    const qrDataUrl = await QRCode.toDataURL(trackUrl, {
      width: 300,
      margin: 2,
      color: { dark: "#0f1117", light: "#fbbf24" },
    });
    res.json({ qrDataUrl, trackUrl, clientName: project.clientName, projectName: project.clientName });
  });

  // ── Public: Client e-signature ──
  app.post("/api/track/:token/sign", (req, res) => {
    const project = storage.getProjectByToken(req.params.token);
    if (!project) return res.status(404).json({ error: "Not found" });
    const sig = storage.createSignature({
      projectId: project.id,
      signerName: req.body.signerName,
      signerRole: "Client",
      signatureDataUrl: req.body.signatureDataUrl,
      agreementText: req.body.agreementText,
      ipAddress: req.ip,
    });
    // Post a milestone update
    storage.createUpdate({
      projectId: project.id,
      message: `✅ Commissioning certificate signed by ${req.body.signerName} on ${new Date().toLocaleDateString("en-PH", { year: "numeric", month: "long", day: "numeric" })}.`,
      type: "milestone",
      postedBy: "SolarIQ",
    });
    res.status(201).json(sig);
  });

  // ── Admin Auth ──
  app.post("/api/admin/login", (req, res) => {
    const { username, password } = req.body;
    const admin = storage.getAdmin(username, password);
    if (!admin) return res.status(401).json({ error: "Invalid credentials" });
    res.json({ ok: true, name: admin.name, token: Buffer.from(`${username}:${password}`).toString("base64") });
  });

  const requireAuth = (req: any, res: any, next: any) => {
    const auth = req.headers.authorization;
    if (!auth?.startsWith("Basic ")) return res.status(401).json({ error: "Unauthorized" });
    const [u, p] = Buffer.from(auth.slice(6), "base64").toString().split(":");
    if (!storage.getAdmin(u, p)) return res.status(401).json({ error: "Unauthorized" });
    next();
  };

  // ── Admin: Projects ──
  app.get("/api/admin/projects", requireAuth, (_req, res) => res.json(storage.getAllProjects()));
  app.post("/api/admin/projects", requireAuth, (req, res) => {
    const data = { ...req.body, shareToken: genToken() };
    const proj = storage.createProject(data);
    const defaults = [
      ["Site Survey & Assessment", "Roof assessment, shading analysis, structural review", "survey", 1],
      ["System Design", "Panel layout, inverter selection, electrical design", "design", 2],
      ["Permit Submission", "Building and electrical permits submitted", "permitting", 3],
      ["Permit Approval", "All permits and utility interconnection approved", "permitting", 4],
      ["Material Procurement", "Panels, inverter, racking, and wiring delivered", "procurement", 5],
      ["Racking Installation", "Roof mounts and racking system installed", "installation", 6],
      ["Panel Installation", "Solar panels mounted and connected", "installation", 7],
      ["Inverter & Electrical Work", "Inverter, wiring, conduit, and electrical connections", "installation", 8],
      ["Final Inspection", "Local authority and utility final inspection", "inspection", 9],
      ["Commissioning & Handover", "System testing, monitoring setup, client walkthrough", "commissioned", 10],
    ];
    defaults.forEach(([t, d, p, o]) => storage.createMilestone({ projectId: proj.id, title: t as string, description: d as string, phase: p as string, sortOrder: o as number, status: "pending" }));
    storage.createUpdate({ projectId: proj.id, message: `Welcome ${proj.clientName}! Your solar installation project has been started. We'll keep you updated every step of the way.`, type: "update", postedBy: "SolarIQ" });
    // Set up notif prefs from project email
    if (proj.clientEmail) {
      storage.upsertNotifPref(proj.id, { projectId: proj.id, email: proj.clientEmail, phone: proj.clientPhone || "", emailEnabled: 1, smsEnabled: 0, notifyOnMilestone: 1, notifyOnUpdate: 1 });
    }
    res.status(201).json(proj);
  });
  app.patch("/api/admin/projects/:id", requireAuth, (req, res) => res.json(storage.updateProject(+req.params.id, req.body)));
  app.delete("/api/admin/projects/:id", requireAuth, (req, res) => { storage.deleteProject(+req.params.id); res.json({ ok: true }); });

  // ── Admin: Milestones ──
  app.get("/api/admin/projects/:id/milestones", requireAuth, (req, res) => res.json(storage.getMilestonesByProject(+req.params.id)));
  app.patch("/api/admin/milestones/:id", requireAuth, async (req, res) => {
    const data = { ...req.body };
    if (data.status === "completed" && !data.completedAt) data.completedAt = new Date().toISOString();
    const updated = storage.updateMilestone(+req.params.id, data);
    // Recalculate progress
    const allMs = storage.getMilestonesByProject(updated!.projectId);
    const done = allMs.filter(m => m.status === "completed").length;
    const pct = allMs.length ? Math.round((done / allMs.length) * 100) : 0;
    storage.updateProject(updated!.projectId, { overallProgress: pct, status: updated!.phase });
    // Send notification if milestone completed
    if (data.status === "completed") {
      const notif = storage.getNotifPref(updated!.projectId);
      const project = storage.getProject(updated!.projectId);
      if (notif?.emailEnabled && notif.email && project) {
        const host = `${req.protocol}://${req.get("host")}`;
        const trackUrl = `${host}/#/track/${project.shareToken}`;
        sendNotificationEmail(notif.email, project.clientName, project.clientName, `Milestone completed: "${updated!.title}". Your installation is now ${pct}% complete.`, trackUrl);
      }
    }
    res.json(updated);
  });

  // ── Admin: Updates/Posts ──
  app.get("/api/admin/projects/:id/updates", requireAuth, (req, res) => res.json(storage.getUpdatesByProject(+req.params.id)));
  app.post("/api/admin/projects/:id/updates", requireAuth, async (req, res) => {
    const update = storage.createUpdate({ ...req.body, projectId: +req.params.id });
    const ms = storage.getMilestonesByProject(+req.params.id);
    const done = ms.filter(m => m.status === "completed").length;
    const pct = ms.length ? Math.round((done / ms.length) * 100) : 0;
    storage.updateProject(+req.params.id, { overallProgress: pct });
    // Send email notification
    const notif = storage.getNotifPref(+req.params.id);
    const project = storage.getProject(+req.params.id);
    if (notif?.emailEnabled && notif.email && project) {
      const host = `${req.protocol}://${req.get("host")}`;
      const trackUrl = `${host}/#/track/${project.shareToken}`;
      const result = await sendNotificationEmail(notif.email, project.clientName, project.clientName, update.message, trackUrl);
      return res.status(201).json({ update, emailResult: result });
    }
    res.status(201).json({ update });
  });
  app.delete("/api/admin/updates/:id", requireAuth, (req, res) => { storage.deleteUpdate(+req.params.id); res.json({ ok: true }); });

  // ── Admin: Photos ──
  app.get("/api/admin/projects/:id/photos", requireAuth, (req, res) => res.json(storage.getPhotosByProject(+req.params.id)));
  app.post("/api/admin/projects/:id/photos", requireAuth, (req, res) => {
    const photo = storage.createPhoto({ ...req.body, projectId: +req.params.id });
    // Auto-post update when photo added
    const project = storage.getProject(+req.params.id);
    if (project) {
      storage.createUpdate({ projectId: +req.params.id, message: `📷 New ${req.body.photoType === "before" ? "before" : req.body.photoType === "after" ? "after" : "progress"} photo added${req.body.caption ? `: ${req.body.caption}` : ""}`, type: "photo", postedBy: req.body.postedBy || "Contractor" });
    }
    res.status(201).json(photo);
  });
  app.delete("/api/admin/photos/:id", requireAuth, (req, res) => { storage.deletePhoto(+req.params.id); res.json({ ok: true }); });

  // ── Admin: Notification prefs ──
  app.get("/api/admin/projects/:id/notif", requireAuth, (req, res) => res.json(storage.getNotifPref(+req.params.id) || null));
  app.post("/api/admin/projects/:id/notif", requireAuth, (req, res) => res.json(storage.upsertNotifPref(+req.params.id, req.body)));

  // ── Admin: Signatures ──
  app.get("/api/admin/projects/:id/signatures", requireAuth, (req, res) => res.json(storage.getSignaturesByProject(+req.params.id)));

  // ── Admin: QR Code (admin version with white background) ──
  app.get("/api/admin/qr/:token", requireAuth, async (req, res) => {
    const project = storage.getProjectByToken(req.params.token);
    if (!project) return res.status(404).json({ error: "Not found" });
    const host = `${req.protocol}://${req.get("host")}`;
    const trackUrl = `${host}/#/track/${req.params.token}`;
    const qrDataUrl = await QRCode.toDataURL(trackUrl, { width: 400, margin: 2, color: { dark: "#000000", light: "#ffffff" } });
    res.json({ qrDataUrl, trackUrl, clientName: project.clientName });
  });

  // ── Admin: FAQs ──
  app.get("/api/admin/faqs", requireAuth, (_req, res) => res.json(storage.getAllFaqs()));
  app.post("/api/admin/faqs", requireAuth, (req, res) => res.status(201).json(storage.createFaq(req.body)));
  app.patch("/api/admin/faqs/:id", requireAuth, (req, res) => res.json(storage.updateFaq(+req.params.id, req.body)));
  app.delete("/api/admin/faqs/:id", requireAuth, (req, res) => { storage.deleteFaq(+req.params.id); res.json({ ok: true }); });

  // ── Admin: Testimonials ──
  app.get("/api/admin/testimonials", requireAuth, (_req, res) => res.json(storage.getAllTestimonials()));
  app.post("/api/admin/testimonials", requireAuth, (req, res) => res.status(201).json(storage.createTestimonial(req.body)));
  app.patch("/api/admin/testimonials/:id", requireAuth, (req, res) => res.json(storage.updateTestimonial(+req.params.id, req.body)));
  app.delete("/api/admin/testimonials/:id", requireAuth, (req, res) => { storage.deleteTestimonial(+req.params.id); res.json({ ok: true }); });

  // ── Admin: Pricing ──
  app.get("/api/admin/pricing", requireAuth, (_req, res) => res.json(storage.getAllPlans()));
  app.post("/api/admin/pricing", requireAuth, (req, res) => res.status(201).json(storage.createPlan(req.body)));
  app.patch("/api/admin/pricing/:id", requireAuth, (req, res) => res.json(storage.updatePlan(+req.params.id, req.body)));
  app.delete("/api/admin/pricing/:id", requireAuth, (req, res) => { storage.deletePlan(+req.params.id); res.json({ ok: true }); });
}
