import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import type { Project, Milestone, Update, Faq, Testimonial, PricingPlan, MilestonePhoto, Signature, NotificationPref } from "@shared/schema";
import {
  LayoutDashboard, ClipboardList, Star, DollarSign, LogOut, Menu, X,
  Plus, Trash2, Edit2, Eye, EyeOff, Copy, CheckCircle2, Clock, Send,
  Camera, QrCode, Bell, PenLine, Download, Image as ImageIcon, RefreshCw
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// ── In-memory auth ──
let _adminToken = "";
let _adminName = "";
const getToken = () => _adminToken;
const authHeaders = () => ({ Authorization: `Basic ${getToken()}`, "Content-Type": "application/json" });
const apiFetch = async (url: string, opts: any = {}) => {
  const r = await fetch(url, { ...opts, headers: { ...authHeaders(), ...(opts.headers || {}) } });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
};

// ── Login ──
function LoginScreen({ onLogin }: { onLogin: (token: string, name: string) => void }) {
  const [u, setU] = useState("admin"); const [p, setP] = useState("solariq2026");
  const [err, setErr] = useState(""); const [loading, setLoading] = useState(false);
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(""); setLoading(true);
    try {
      const res = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: u, password: p }) });
      if (!res.ok) { setErr("Invalid credentials"); return; }
      const data = await res.json(); onLogin(data.token, data.name);
    } catch { setErr("Server error"); } finally { setLoading(false); }
  };
  return (
    <div className="min-h-screen bg-[hsl(220_28%_6%)] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2.5 justify-center mb-8">
          <svg width="36" height="36" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="8" fill="#fbbf24"/><circle cx="16" cy="16" r="4" fill="white" opacity="0.95"/></svg>
          <span className="font-black text-xl text-white">Solar<span className="text-[#fbbf24]">IQ</span></span>
        </div>
        <div className="bg-[hsl(220_24%_9%)] border border-[hsl(220_18%_18%)] rounded-2xl p-8">
          <h2 className="font-bold text-white mb-6 text-center">Admin Login</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <div><label className="text-xs text-white/50 mb-1 block">Username</label>
              <Input value={u} onChange={e => setU(e.target.value)} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white" /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Password</label>
              <Input value={p} onChange={e => setP(e.target.value)} type="password" className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white" /></div>
            {err && <p className="text-red-400 text-xs">{err}</p>}
            <Button type="submit" disabled={loading} className="w-full bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold">{loading ? "Logging in..." : "Login"}</Button>
          </form>
          <p className="text-center text-white/30 text-xs mt-4">Demo: admin / solariq2026</p>
        </div>
      </div>
    </div>
  );
}

// ── Projects Tab ──
function ProjectsTab({ adminName }: { adminName: string }) {
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState<"milestones" | "photos" | "updates" | "qr" | "notif" | "signatures">("milestones");
  const [newUpdate, setNewUpdate] = useState("");
  const [photoCaption, setPhotoCaption] = useState("");
  const [photoType, setPhotoType] = useState<"before" | "progress" | "after">("progress");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({ clientName: "", clientEmail: "", clientPhone: "", address: "", systemKw: "8", panelCount: "20", contractValue: "192000", startDate: "", estimatedEndDate: "" });

  const { data: projects = [], refetch } = useQuery<Project[]>({ queryKey: ["/api/admin/projects"], queryFn: () => apiFetch("/api/admin/projects") });
  const { data: milestones = [] } = useQuery<Milestone[]>({ queryKey: ["/api/admin/milestones", selectedId], queryFn: () => apiFetch(`/api/admin/projects/${selectedId}/milestones`), enabled: !!selectedId });
  const { data: updates = [], refetch: refetchUpdates } = useQuery<Update[]>({ queryKey: ["/api/admin/updates", selectedId], queryFn: () => apiFetch(`/api/admin/projects/${selectedId}/updates`), enabled: !!selectedId });
  const { data: photos = [], refetch: refetchPhotos } = useQuery<MilestonePhoto[]>({ queryKey: ["/api/admin/photos", selectedId], queryFn: () => apiFetch(`/api/admin/projects/${selectedId}/photos`), enabled: !!selectedId });
  const { data: qrData } = useQuery<{ qrDataUrl: string; trackUrl: string }>({ queryKey: ["/api/admin/qr", selectedId], queryFn: () => { const p = projects.find(x => x.id === selectedId); return p ? apiFetch(`/api/admin/qr/${p.shareToken}`) : null; }, enabled: !!selectedId && activeDetailTab === "qr" });
  const { data: notifPref } = useQuery<NotificationPref | null>({ queryKey: ["/api/admin/notif", selectedId], queryFn: () => apiFetch(`/api/admin/projects/${selectedId}/notif`).catch(() => null), enabled: !!selectedId && activeDetailTab === "notif" });
  const { data: sigs = [] } = useQuery<Signature[]>({ queryKey: ["/api/admin/sigs", selectedId], queryFn: () => apiFetch(`/api/admin/projects/${selectedId}/signatures`), enabled: !!selectedId && activeDetailTab === "signatures" });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiFetch("/api/admin/projects", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { refetch(); setAdding(false); toast({ title: "Project created! Tracking link ready." }); },
  });
  const updateMsMutation = useMutation({
    mutationFn: ({ id, data }: any) => apiFetch(`/api/admin/milestones/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/milestones", selectedId] }); refetch(); },
  });
  const postUpdateMutation = useMutation({
    mutationFn: (msg: string) => apiFetch(`/api/admin/projects/${selectedId}/updates`, { method: "POST", body: JSON.stringify({ message: msg, type: "update", postedBy: adminName }) }),
    onSuccess: () => { refetchUpdates(); setNewUpdate(""); toast({ title: "Update posted + email sent to client" }); },
  });
  const uploadPhotoMutation = useMutation({
    mutationFn: (data: any) => apiFetch(`/api/admin/projects/${selectedId}/photos`, { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { refetchPhotos(); setPhotoCaption(""); toast({ title: "Photo uploaded" }); },
  });
  const deletePhotoMutation = useMutation({
    mutationFn: (id: number) => apiFetch(`/api/admin/photos/${id}`, { method: "DELETE" }),
    onSuccess: () => refetchPhotos(),
  });
  const saveNotifMutation = useMutation({
    mutationFn: (data: any) => apiFetch(`/api/admin/projects/${selectedId}/notif`, { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/notif", selectedId] }); toast({ title: "Notification preferences saved" }); },
  });

  const [notifForm, setNotifForm] = useState({ email: "", phone: "", emailEnabled: true, notifyOnMilestone: true, notifyOnUpdate: true });
  const sel = projects.find(p => p.id === selectedId);
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));
  const copyLink = (token: string) => { navigator.clipboard?.writeText(`${window.location.origin}/#/track/${token}`); toast({ title: "Tracking link copied!" }); };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      uploadPhotoMutation.mutate({ dataUrl: ev.target?.result, caption: photoCaption, photoType, postedBy: adminName, milestoneId: 0 });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const DETAIL_TABS = [
    { id: "milestones", label: "Milestones", icon: CheckCircle2 },
    { id: "updates", label: "Updates", icon: Send },
    { id: "photos", label: "Photos", icon: Camera },
    { id: "qr", label: "QR Code", icon: QrCode },
    { id: "notif", label: "Notifications", icon: Bell },
    { id: "signatures", label: "Signatures", icon: PenLine },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-white">Projects ({projects.length})</h2>
        <Button onClick={() => setAdding(v => !v)} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] text-sm font-bold hover:brightness-110">
          <Plus size={14} className="mr-1.5" /> New Project
        </Button>
      </div>

      {adding && (
        <Card className="bg-[hsl(220_24%_9%)] border-[#fbbf24]/30">
          <CardHeader className="pb-2"><CardTitle className="text-sm text-white">New Installation Project</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {[["clientName","Client Name *"],["clientEmail","Email (for notifications)"],["clientPhone","Phone"],["address","Address *"]].map(([k,l]) => (
                <div key={k} className={k === "address" ? "col-span-2" : ""}>
                  <label className="text-xs text-white/50">{l}</label>
                  <Input value={(form as any)[k]} onChange={e => set(k, e.target.value)} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm" />
                </div>
              ))}
              {[["systemKw","System kWp"],["panelCount","Panels"],["contractValue","Contract ₱"],["startDate","Start Date"],["estimatedEndDate","Est. End Date"]].map(([k,l]) => (
                <div key={k}><label className="text-xs text-white/50">{l}</label>
                  <Input value={(form as any)[k]} onChange={e => set(k, e.target.value)} type={k.includes("Date") ? "date" : "text"} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm" /></div>
              ))}
            </div>
            <div className="flex gap-2">
              <Button onClick={() => createMutation.mutate({ ...form, systemKw: +form.systemKw, panelCount: +form.panelCount, contractValue: +form.contractValue, status: "survey", overallProgress: 0 })} disabled={!form.clientName || !form.address || createMutation.isPending} className="flex-1 bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold text-sm">Create & Generate Link</Button>
              <Button variant="outline" onClick={() => setAdding(false)} className="border-[hsl(220_18%_22%)] text-white text-sm">Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-5 gap-4">
        {/* Left: project list */}
        <div className="lg:col-span-2 space-y-2">
          {projects.map(p => (
            <button key={p.id} onClick={() => setSelectedId(p.id === selectedId ? null : p.id)} className={`w-full text-left p-4 rounded-xl border transition-all ${p.id === selectedId ? "border-[#fbbf24]/50 bg-[#fbbf24]/5" : "border-[hsl(220_18%_16%)] bg-[hsl(220_24%_9%)] hover:border-[#fbbf24]/25"}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="font-semibold text-white text-sm">{p.clientName}</div>
                <Badge className={`text-[10px] ${p.status === "commissioned" ? "bg-green-500/15 text-green-400 border-green-500/30" : "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/25"} border`}>{p.status}</Badge>
              </div>
              <div className="text-xs text-white/40 mb-2 truncate">{p.address}</div>
              <div className="h-1.5 rounded-full bg-[hsl(220_18%_18%)]"><div className="h-full rounded-full bg-[#fbbf24]" style={{ width: `${p.overallProgress}%` }} /></div>
              <div className="flex items-center justify-between mt-1 text-[10px] text-white/30">
                <span>{p.systemKw} kWp</span>
                <span>{p.overallProgress}%</span>
              </div>
              <div className="flex gap-3 mt-2">
                <button onClick={e => { e.stopPropagation(); copyLink(p.shareToken); }} className="text-[10px] text-[#fbbf24]/60 hover:text-[#fbbf24] flex items-center gap-1 transition-colors">
                  <Copy size={9} /> Copy link
                </button>
                <a href={`/#/track/${p.shareToken}`} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="text-[10px] text-white/30 hover:text-white/60 flex items-center gap-1 transition-colors">
                  <Eye size={9} /> Preview
                </a>
              </div>
            </button>
          ))}
        </div>

        {/* Right: detail panel */}
        {sel && (
          <div className="lg:col-span-3 bg-[hsl(220_24%_9%)] border border-[hsl(220_18%_16%)] rounded-xl overflow-hidden">
            {/* Sub-tabs */}
            <div className="flex overflow-x-auto border-b border-[hsl(220_18%_16%)]">
              {DETAIL_TABS.map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => setActiveDetailTab(id as any)} className={`flex items-center gap-1.5 px-3 py-2.5 text-xs whitespace-nowrap transition-colors shrink-0 ${activeDetailTab === id ? "border-b-2 border-[#fbbf24] text-[#fbbf24]" : "text-white/40 hover:text-white/70"}`}>
                  <Icon size={11} />{label}
                </button>
              ))}
            </div>

            <div className="p-4">
              {/* Milestones */}
              {activeDetailTab === "milestones" && (
                <div className="space-y-1.5 max-h-80 overflow-y-auto">
                  {milestones.sort((a,b) => a.sortOrder-b.sortOrder).map(m => (
                    <div key={m.id} className="flex items-center gap-2 p-2 rounded-lg bg-[hsl(220_20%_12%)]">
                      <Select value={m.status} onValueChange={v => updateMsMutation.mutate({ id: m.id, data: { status: v } })}>
                        <SelectTrigger className={`h-6 w-28 text-[10px] border rounded-full px-2 shrink-0 ${m.status === "completed" ? "border-green-500/30 text-green-400 bg-green-500/10" : m.status === "in_progress" ? "border-[#fbbf24]/30 text-[#fbbf24] bg-[#fbbf24]/10" : "border-[hsl(220_18%_22%)] text-white/40"}`}><SelectValue /></SelectTrigger>
                        <SelectContent>{["pending","in_progress","completed","blocked"].map(s => <SelectItem key={s} value={s}>{s.replace("_"," ")}</SelectItem>)}</SelectContent>
                      </Select>
                      <span className={`text-xs flex-1 truncate ${m.status === "pending" ? "text-white/40" : "text-white/80"}`}>{m.title}</span>
                      {m.status === "completed" && <CheckCircle2 size={12} className="text-green-400 shrink-0" />}
                    </div>
                  ))}
                </div>
              )}

              {/* Updates */}
              {activeDetailTab === "updates" && (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Input value={newUpdate} onChange={e => setNewUpdate(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && newUpdate.trim()) postUpdateMutation.mutate(newUpdate.trim()); }} placeholder="Type update — client gets email notification..." className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white text-sm h-9 flex-1" />
                    <Button onClick={() => postUpdateMutation.mutate(newUpdate.trim())} disabled={!newUpdate.trim() || postUpdateMutation.isPending} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] h-9 px-3 font-bold shrink-0"><Send size={13} /></Button>
                  </div>
                  <div className="text-xs text-white/30 flex items-center gap-1"><Bell size={10} /> Client receives email notification automatically</div>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {updates.map(u => (
                      <div key={u.id} className="text-xs text-white/50 px-3 py-2 bg-[hsl(220_20%_12%)] rounded-lg">{u.message}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* Photos */}
              {activeDetailTab === "photos" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-2 mb-1">
                    <div><label className="text-xs text-white/50">Type</label>
                      <Select value={photoType} onValueChange={v => setPhotoType(v as any)}>
                        <SelectTrigger className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-7 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent><SelectItem value="before">Before</SelectItem><SelectItem value="progress">Progress</SelectItem><SelectItem value="after">After</SelectItem></SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2"><label className="text-xs text-white/50">Caption</label>
                      <Input value={photoCaption} onChange={e => setPhotoCaption(e.target.value)} placeholder="e.g. Racking installed" className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-7 text-xs" />
                    </div>
                  </div>
                  <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                  <Button onClick={() => fileInputRef.current?.click()} disabled={uploadPhotoMutation.isPending} className="w-full bg-[hsl(220_20%_16%)] border border-[hsl(220_18%_22%)] text-white text-xs h-9 hover:border-[#fbbf24]/40">
                    <Camera size={13} className="mr-2" /> {uploadPhotoMutation.isPending ? "Uploading..." : "Upload Photo"}
                  </Button>
                  <div className="text-xs text-white/30">Upload Before + After photos to enable the comparison slider on the client tracker.</div>
                  {photos.length > 0 && (
                    <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
                      {photos.map(p => (
                        <div key={p.id} className="relative group">
                          <img src={p.dataUrl} alt={p.caption || ""} className="w-full h-20 rounded-lg object-cover" />
                          <div className="absolute top-1 left-1"><span className="text-[9px] bg-black/60 text-[#fbbf24] px-1 rounded">{p.photoType}</span></div>
                          <button onClick={() => deletePhotoMutation.mutate(p.id)} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 bg-red-500 rounded p-0.5 transition-opacity"><X size={10} className="text-white" /></button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* QR Code */}
              {activeDetailTab === "qr" && (
                <div className="text-center space-y-3">
                  {qrData ? (
                    <>
                      <img src={qrData.qrDataUrl} alt="QR Code" className="mx-auto w-40 h-40 rounded-xl" />
                      <p className="text-xs text-white/40 break-all">{qrData.trackUrl}</p>
                      <div className="flex gap-2 justify-center">
                        <a href={qrData.qrDataUrl} download="qr-code.png" className="flex items-center gap-1.5 text-xs bg-[hsl(220_20%_16%)] border border-[hsl(220_18%_22%)] text-white px-3 py-2 rounded-lg hover:border-[#fbbf24]/40 transition-colors">
                          <Download size={12} /> Download QR
                        </a>
                        <button onClick={() => { navigator.clipboard?.writeText(qrData.trackUrl); }} className="flex items-center gap-1.5 text-xs bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold px-3 py-2 rounded-lg hover:brightness-110 transition-all">
                          <Copy size={12} /> Copy Link
                        </button>
                      </div>
                      <p className="text-xs text-white/30">Print this QR on proposals, contracts, or invoices so clients can instantly access their tracker.</p>
                    </>
                  ) : (
                    <div className="py-8 text-white/30 text-sm"><RefreshCw size={16} className="mx-auto mb-2 animate-spin" />Loading QR...</div>
                  )}
                </div>
              )}

              {/* Notification Preferences */}
              {activeDetailTab === "notif" && (
                <div className="space-y-4">
                  <div className="text-xs text-white/50 flex items-center gap-1.5 mb-3"><Bell size={12} /> Client gets email when you post an update or complete a milestone</div>
                  <div className="space-y-3">
                    <div><label className="text-xs text-white/50">Client Email</label>
                      <Input
                        defaultValue={notifPref?.email || sel.clientEmail || ""}
                        id="notif-email"
                        className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm"
                        placeholder="client@email.com"
                      />
                    </div>
                    <div><label className="text-xs text-white/50">Client Phone (for SMS)</label>
                      <Input
                        defaultValue={notifPref?.phone || sel.clientPhone || ""}
                        id="notif-phone"
                        className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm"
                        placeholder="+63 917 123 4567"
                      />
                    </div>
                    {[
                      ["emailEnabled", "Email notifications enabled"],
                      ["notifyOnMilestone", "Notify on milestone completion"],
                      ["notifyOnUpdate", "Notify on new update posts"],
                    ].map(([k, l]) => (
                      <label key={k} className="flex items-center gap-2.5 cursor-pointer">
                        <input type="checkbox" id={`notif-${k}`} defaultChecked={(notifPref as any)?.[k] !== 0} className="w-4 h-4 accent-[#fbbf24]" />
                        <span className="text-xs text-white/70">{l}</span>
                      </label>
                    ))}
                  </div>
                  <Button
                    onClick={() => saveNotifMutation.mutate({
                      email: (document.getElementById("notif-email") as HTMLInputElement)?.value || "",
                      phone: (document.getElementById("notif-phone") as HTMLInputElement)?.value || "",
                      emailEnabled: (document.getElementById("notif-emailEnabled") as HTMLInputElement)?.checked ? 1 : 0,
                      notifyOnMilestone: (document.getElementById("notif-notifyOnMilestone") as HTMLInputElement)?.checked ? 1 : 0,
                      notifyOnUpdate: (document.getElementById("notif-notifyOnUpdate") as HTMLInputElement)?.checked ? 1 : 0,
                    })}
                    disabled={saveNotifMutation.isPending}
                    className="w-full bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold text-sm"
                  >
                    Save Notification Settings
                  </Button>
                </div>
              )}

              {/* Signatures */}
              {activeDetailTab === "signatures" && (
                <div className="space-y-3">
                  {sigs.length === 0 ? (
                    <div className="text-center py-8 text-white/30 text-sm">
                      <PenLine size={24} className="mx-auto mb-2" />
                      No signatures yet. Client can sign the commissioning certificate from the tracker page when status is "commissioned".
                    </div>
                  ) : sigs.map(sig => (
                    <div key={sig.id} className="bg-[hsl(220_20%_12%)] rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <div className="font-semibold text-white text-sm">{sig.signerName}</div>
                          <div className="text-xs text-white/40">{sig.signerRole} · {new Date(sig.signedAt).toLocaleDateString("en-PH", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}</div>
                        </div>
                        <CheckCircle2 size={18} className="text-green-400" />
                      </div>
                      <img src={sig.signatureDataUrl} alt="Signature" className="w-full h-16 object-contain rounded-lg bg-[#1f2937] border border-[hsl(220_18%_22%)]" />
                      {sig.agreementText && <p className="text-[10px] text-white/30 mt-2 italic">{sig.agreementText}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── FAQ Tab ──
function FaqTab() {
  const { toast } = useToast();
  const [editing, setEditing] = useState<number | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ question: "", answer: "", category: "general" });
  const [editForm, setEditForm] = useState({ question: "", answer: "", category: "general" });
  const { data: faqs = [], refetch } = useQuery<Faq[]>({ queryKey: ["/api/admin/faqs"], queryFn: () => apiFetch("/api/admin/faqs") });
  const addMutation = useMutation({
    mutationFn: (d: any) => apiFetch("/api/admin/faqs", { method: "POST", body: JSON.stringify({ ...d, published: 1 }) }),
    onSuccess: () => { refetch(); setAdding(false); setForm({ question: "", answer: "", category: "general" }); toast({ title: "FAQ added" }); },
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: any) => apiFetch(`/api/admin/faqs/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => { refetch(); setEditing(null); toast({ title: "FAQ updated" }); },
  });
  const deleteMutation = useMutation({ mutationFn: (id: number) => apiFetch(`/api/admin/faqs/${id}`, { method: "DELETE" }), onSuccess: () => { refetch(); } });
  const startEdit = (f: Faq) => { setEditing(f.id); setEditForm({ question: f.question, answer: f.answer, category: f.category }); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-white">FAQ Editor ({faqs.length} items)</h2>
        <Button onClick={() => setAdding(v => !v)} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] text-sm font-bold hover:brightness-110"><Plus size={14} className="mr-1.5"/>Add FAQ</Button>
      </div>
      {adding && (
        <Card className="bg-[hsl(220_24%_9%)] border-[#fbbf24]/30">
          <CardContent className="p-4 space-y-3">
            <div><label className="text-xs text-white/50">Category</label>
              <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                <SelectTrigger className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>{["general","installation","billing","permits","technical","monitoring","maintenance","structural"].map(c => <SelectItem key={c} value={c}>{c.charAt(0).toUpperCase()+c.slice(1)}</SelectItem>)}</SelectContent>
              </Select></div>
            <div><label className="text-xs text-white/50">Question</label><Input value={form.question} onChange={e => setForm(f => ({ ...f, question: e.target.value }))} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 text-sm" /></div>
            <div><label className="text-xs text-white/50">Answer</label><textarea value={form.answer} onChange={e => setForm(f => ({ ...f, answer: e.target.value }))} rows={3} className="w-full bg-[hsl(220_20%_13%)] border border-[hsl(220_18%_22%)] text-white rounded-lg p-2 text-sm mt-1 resize-none" /></div>
            <div className="flex gap-2">
              <Button onClick={() => addMutation.mutate(form)} disabled={!form.question || !form.answer} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold text-sm flex-1">Save FAQ</Button>
              <Button variant="outline" onClick={() => setAdding(false)} className="border-[hsl(220_18%_22%)] text-white text-sm">Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}
      <div className="space-y-2">
        {faqs.map(faq => (
          <div key={faq.id} className="bg-[hsl(220_24%_9%)] border border-[hsl(220_18%_16%)] rounded-xl overflow-hidden">
            {editing === faq.id ? (
              <div className="p-4 space-y-3">
                <div><label className="text-xs text-white/50">Question</label><Input value={editForm.question} onChange={e => setEditForm(f => ({ ...f, question: e.target.value }))} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 text-sm" /></div>
                <div><label className="text-xs text-white/50">Answer</label><textarea value={editForm.answer} onChange={e => setEditForm(f => ({ ...f, answer: e.target.value }))} rows={3} className="w-full bg-[hsl(220_20%_13%)] border border-[hsl(220_18%_22%)] text-white rounded-lg p-2 text-sm mt-1 resize-none" /></div>
                <div className="flex gap-2">
                  <Button onClick={() => updateMutation.mutate({ id: faq.id, data: editForm })} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold text-xs">Save</Button>
                  <Button variant="outline" onClick={() => setEditing(null)} className="border-[hsl(220_18%_22%)] text-white text-xs">Cancel</Button>
                </div>
              </div>
            ) : (
              <div className="p-4 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white">{faq.question}</div>
                  <div className="text-xs text-white/40 mt-1 line-clamp-2">{faq.answer}</div>
                  <Badge className="mt-2 text-[10px] bg-[hsl(220_20%_14%)] text-white/40 border-transparent">{faq.category}</Badge>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => updateMutation.mutate({ id: faq.id, data: { published: faq.published ? 0 : 1 } })} className={`p-1.5 rounded ${faq.published ? "text-green-400" : "text-white/30"} transition-colors`}>{faq.published ? <Eye size={13}/> : <EyeOff size={13}/>}</button>
                  <button onClick={() => startEdit(faq)} className="p-1.5 text-white/40 hover:text-[#fbbf24] transition-colors"><Edit2 size={13}/></button>
                  <button onClick={() => deleteMutation.mutate(faq.id)} className="p-1.5 text-white/30 hover:text-red-400 transition-colors"><Trash2 size={13}/></button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Testimonials Tab ──
function TestimonialsTab() {
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", location: "", role: "Homeowner", quote: "", rating: 5, systemSize: "", avatarInitials: "" });
  const { data: items = [], refetch } = useQuery<Testimonial[]>({ queryKey: ["/api/admin/testimonials"], queryFn: () => apiFetch("/api/admin/testimonials") });
  const addMutation = useMutation({ mutationFn: (d: any) => apiFetch("/api/admin/testimonials", { method: "POST", body: JSON.stringify({ ...d, published: 1 }) }), onSuccess: () => { refetch(); setAdding(false); toast({ title: "Testimonial added" }); } });
  const toggleMutation = useMutation({ mutationFn: ({ id, published }: any) => apiFetch(`/api/admin/testimonials/${id}`, { method: "PATCH", body: JSON.stringify({ published: published ? 0 : 1 }) }), onSuccess: () => refetch() });
  const deleteMutation = useMutation({ mutationFn: (id: number) => apiFetch(`/api/admin/testimonials/${id}`, { method: "DELETE" }), onSuccess: () => refetch() });
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-white">Testimonials ({items.length})</h2>
        <Button onClick={() => setAdding(v => !v)} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] text-sm font-bold hover:brightness-110"><Plus size={14} className="mr-1.5"/>Add Review</Button>
      </div>
      {adding && (
        <Card className="bg-[hsl(220_24%_9%)] border-[#fbbf24]/30">
          <CardContent className="p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {[["name","Name *"],["location","Location"],["role","Role"],["systemSize","System Size"],["avatarInitials","Initials"]].map(([k,l]) => (
                <div key={k}><label className="text-xs text-white/50">{l}</label><Input value={(form as any)[k]} onChange={e => set(k, e.target.value)} className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm" /></div>
              ))}
              <div><label className="text-xs text-white/50">Rating</label>
                <Select value={form.rating.toString()} onValueChange={v => set("rating", +v)}>
                  <SelectTrigger className="bg-[hsl(220_20%_13%)] border-[hsl(220_18%_22%)] text-white mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>{[5,4,3].map(r => <SelectItem key={r} value={r.toString()}>{"★".repeat(r)}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><label className="text-xs text-white/50">Quote *</label><textarea value={form.quote} onChange={e => set("quote", e.target.value)} rows={3} className="w-full bg-[hsl(220_20%_13%)] border border-[hsl(220_18%_22%)] text-white rounded-lg p-2 text-sm mt-1 resize-none" /></div>
            <div className="flex gap-2">
              <Button onClick={() => addMutation.mutate(form)} disabled={!form.name || !form.quote} className="bg-[#fbbf24] text-[hsl(220_28%_6%)] font-bold text-sm flex-1">Add</Button>
              <Button variant="outline" onClick={() => setAdding(false)} className="border-[hsl(220_18%_22%)] text-white text-sm">Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}
      <div className="grid sm:grid-cols-2 gap-3">
        {items.map(t => (
          <div key={t.id} className={`bg-[hsl(220_24%_9%)] border rounded-xl p-4 ${t.published ? "border-[hsl(220_18%_16%)]" : "border-[hsl(220_18%_16%)] opacity-50"}`}>
            <div className="flex items-start justify-between gap-2 mb-2">
              <div><div className="font-semibold text-white text-sm">{t.name}</div><div className="text-xs text-white/40">{t.role}{t.location ? ` · ${t.location}` : ""}</div></div>
              <div className="flex items-center gap-1">
                <button onClick={() => toggleMutation.mutate({ id: t.id, published: t.published })} className={`p-1.5 ${t.published ? "text-green-400" : "text-white/30"}`}>{t.published ? <Eye size={13}/> : <EyeOff size={13}/>}</button>
                <button onClick={() => deleteMutation.mutate(t.id)} className="p-1.5 text-white/30 hover:text-red-400"><Trash2 size={13}/></button>
              </div>
            </div>
            <p className="text-xs text-white/60 line-clamp-3">"{t.quote}"</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Pricing Tab ──
function PricingTab() {
  const { data: plans = [] } = useQuery<PricingPlan[]>({ queryKey: ["/api/admin/pricing"], queryFn: () => apiFetch("/api/admin/pricing") });
  return (
    <div className="space-y-4">
      <h2 className="font-bold text-white">Pricing Plans</h2>
      <div className="grid sm:grid-cols-3 gap-4">
        {plans.map(plan => {
          const feats: string[] = JSON.parse(plan.features || "[]");
          return (
            <div key={plan.id} className={`bg-[hsl(220_24%_9%)] border rounded-xl p-5 ${plan.highlighted ? "border-[#fbbf24]/40" : "border-[hsl(220_18%_16%)]"}`}>
              <div className="font-bold text-white mb-1">{plan.name}</div>
              <div className="text-2xl font-black text-[#fbbf24] mb-3">₱{plan.price.toLocaleString()}<span className="text-xs font-normal text-white/40">/{plan.billingCycle}</span></div>
              <ul className="space-y-1.5">
                {feats.map(f => <li key={f} className="text-xs text-white/60 flex items-start gap-1.5"><CheckCircle2 size={10} className="text-[#fbbf24] shrink-0 mt-0.5"/>{f}</li>)}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Main ──
export default function AdminPage() {
  const [authToken, setAuthToken] = useState(_adminToken);
  const [adminName, setAdminName] = useState(_adminName);
  const [tab, setTab] = useState("projects");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogin = (token: string, name: string) => { _adminToken = token; _adminName = name; setAuthToken(token); setAdminName(name); };
  const handleLogout = () => { _adminToken = ""; _adminName = ""; setAuthToken(""); setAdminName(""); };

  if (!authToken) return <LoginScreen onLogin={handleLogin} />;

  const tabs = [
    { id: "projects", label: "Projects", icon: LayoutDashboard },
    { id: "faqs", label: "FAQ Editor", icon: ClipboardList },
    { id: "testimonials", label: "Testimonials", icon: Star },
    { id: "pricing", label: "Pricing", icon: DollarSign },
  ];

  return (
    <div className="min-h-screen bg-[hsl(220_28%_6%)] flex">
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 flex flex-col w-56 bg-[hsl(220_24%_9%)] border-r border-[hsl(220_18%_14%)] transition-transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="flex items-center gap-2 px-5 py-4 border-b border-[hsl(220_18%_14%)]">
          <svg width="22" height="22" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="8" fill="#fbbf24"/><circle cx="16" cy="16" r="4" fill="white" opacity="0.95"/></svg>
          <span className="font-bold text-sm text-white">Solar<span className="text-[#fbbf24]">IQ</span> Admin</span>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => { setTab(id); setSidebarOpen(false); }} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors text-left ${tab === id ? "bg-[#fbbf24]/15 text-[#fbbf24] font-medium" : "text-white/50 hover:text-white hover:bg-[hsl(220_20%_14%)]"}`}>
              <Icon size={14} />{label}
            </button>
          ))}
        </nav>
        <div className="px-3 py-4 border-t border-[hsl(220_18%_14%)]">
          <div className="text-xs text-white/40 px-3 mb-2">Logged in as {adminName}</div>
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-white/40 hover:text-red-400 transition-colors"><LogOut size={13} /> Logout</button>
          <a href="https://www.perplexity.ai/computer" target="_blank" rel="noopener noreferrer" className="block text-[10px] text-white/20 px-3 mt-3 hover:text-white/40">Created with Perplexity Computer</a>
        </div>
      </aside>
      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="flex items-center gap-3 px-4 py-3 border-b border-[hsl(220_18%_14%)] lg:hidden bg-[hsl(220_24%_9%)]">
          <button onClick={() => setSidebarOpen(true)} className="text-white/50 hover:text-white"><Menu size={20} /></button>
          <span className="font-bold text-sm text-white">SolarIQ Admin</span>
        </header>
        <main className="flex-1 p-4 lg:p-7 overflow-auto">
          <div className="max-w-5xl mx-auto">
            {tab === "projects" && <ProjectsTab adminName={adminName} />}
            {tab === "faqs" && <FaqTab />}
            {tab === "testimonials" && <TestimonialsTab />}
            {tab === "pricing" && <PricingTab />}
          </div>
        </main>
      </div>
    </div>
  );
}
